package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoginController implements Initializable {
    public LoginModel loginmodel= new LoginModel();
    public LoginModel loginmodel1= new LoginModel();



    @FXML
    javafx.scene.control.Label isConnected;
    @FXML
    javafx.scene.control.TextField txtUsername;
    @FXML
    javafx.scene.control.PasswordField txtPassword;
    @FXML
    javafx.scene.control.TextField txtname;
    @FXML
    javafx.scene.control.TextField txtsurname;
    @FXML
    javafx.scene.control.TextField txtage;
    @FXML
    javafx.scene.control.TextField txtusername;
    @FXML
    javafx.scene.control.TextField txtpassword;




    @Override
public void initialize(URL location,ResourceBundle resources){

    if (loginmodel.isDbConnected()){
        isConnected.setText(" Kullanıcı adı ve parolanızı giriniz");
    }else {
        isConnected.setText("");
    }

    }
public void Login(ActionEvent event){
        try{
            if (loginmodel.Login(txtUsername.getText(),txtPassword.getText())){
                isConnected.setText("sayfaya yönlendiriliyorsunuz");
                FXMLLoader loader = new FXMLLoader(getClass().getResource("sample.fxml"));
                Parent root = loader.load();
                Controller controller = loader.getController();
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                stage.setScene(scene);

                stage.show();



            }else {
                isConnected.setText("yanlış bilgi girdiniz,tekrar deneyiniz veya kayıt olunuz!");
            }
        }catch (SQLException | IOException e){
            isConnected.setText("başarısız");
            e.printStackTrace();

        }


}



    public void kayitol(ActionEvent event){

        try{

            if (loginmodel1.kayitol(txtname.getText(), txtsurname.getText(), txtage.getText(), txtusername.getText(), txtpassword.getText())){
                isConnected.setText("Kayıt oluşturuldu, Giriş yapabilirsiniz");







            }else {
                isConnected.setText("Kayıt Oluşturuldu,Giriş Yapabilirsiniz");
            }
        }catch (SQLException  e){
            isConnected.setText("başarısız");
            e.printStackTrace();

        }


    }


    }













