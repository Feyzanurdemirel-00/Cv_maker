package sample;


import com.sun.glass.ui.CommonDialogs;
import com.sun.glass.ui.View;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.stage.*;
import javafx.stage.Window;
import org.sqlite.SQLiteJDBCLoader;


import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller {


    public Button fileButton;
    @FXML
    javafx.scene.control.TextField textfield1;
    @FXML
    javafx.scene.control.TextField textfield2;
    @FXML
    javafx.scene.control.TextField textfield3;

    @FXML
    javafx.scene.control.TextField telefon;
    @FXML
    javafx.scene.control.TextField email;
    @FXML
    javafx.scene.control.TextArea textarea1;
    @FXML
    javafx.scene.control.CheckBox kadın;
    @FXML
    javafx.scene.control.CheckBox erkek;
    @FXML
    javafx.scene.control.TextField referans;
    @FXML
    javafx.scene.control.TextField referans2;
    @FXML
    Label resimm;
    @FXML
    javafx.scene.control.TextField numara1;
    @FXML
    javafx.scene.control.TextField numara2;
    @FXML
    javafx.scene.control.TextField liseadı;
    @FXML
    javafx.scene.control.TextField lisealan;
    @FXML
    javafx.scene.control.TextField lisansadı;
    @FXML
    javafx.scene.control.TextField lisansbölüm;

    @FXML
    javafx.scene.control.TextArea hobiler;
    @FXML
    javafx.scene.control.TextField dogum;
    @FXML
    javafx.scene.control.TextField lisestart;
    @FXML
    javafx.scene.control.TextField liseend;
    @FXML
    javafx.scene.control.TextField lisansstart;
    @FXML
    javafx.scene.control.TextField lisansend;
    @FXML
    javafx.scene.control.TextField ünvan;
    @FXML
    javafx.scene.control.TextField iş1adı;
    @FXML
    javafx.scene.control.TextField iş2adı;
    @FXML
    javafx.scene.control.TextField pozisyon1;
    @FXML
    javafx.scene.control.TextField pozisyon2;
    @FXML
    javafx.scene.control.TextField işstart1;
    @FXML
    javafx.scene.control.TextField işstart2;
    @FXML
    javafx.scene.control.TextField işend1;
    @FXML
    javafx.scene.control.TextField işend2;
    @FXML
    javafx.scene.control.TextArea adres1;
    @FXML
    javafx.scene.control.TextArea adres2;
    @FXML
    javafx.scene.control.TextField yabancı;

    @FXML
    public Label adid1;

    @FXML
    public Button cvyegit;
    @FXML
    public ImageView ImageView;

    private Window stage;





    @FXML
    private void file(ActionEvent event) throws IOException {
            FileChooser fil_chooser = new FileChooser();
            File file =fil_chooser.showOpenDialog(stage);

            if (file != null) {
                BufferedImage bufferedImage = ImageIO.read(file);
                WritableImage image = SwingFXUtils.toFXImage(bufferedImage, null);
                ImageView.setImage(image);
                resimm.setText(file.getAbsolutePath()
                        + "  selected");
            }
        }



    @FXML
    private void form2(ActionEvent event) {

        FXMLLoader loader = new FXMLLoader(getClass().getResource("FXMLcv.fxml"));


        try {
            Parent root = loader.load();
            FXMLcv fxmLcv = loader.getController();
            fxmLcv.setIsim1(textfield1.getText());
            fxmLcv.setTc(textfield2.getText());

            fxmLcv.setTelefon(telefon.getText());
            fxmLcv.setEmail(email.getText());
            fxmLcv.setAdres(textarea1.getText());
            fxmLcv.setCinsiyet(kadın.getText());
            fxmLcv.setMedenidurum(textfield3.getText());


            fxmLcv.setReferans(referans.getText());
            fxmLcv.setNumara1(numara1.getText());
            fxmLcv.setReferans2(referans2.getText());
            fxmLcv.setNumara2(numara2.getText());
            fxmLcv.setLiseadı(liseadı.getText());
            fxmLcv.setLisealan(lisealan.getText());
            fxmLcv.setLisansadı(lisansadı.getText());
            fxmLcv.setLisansbölüm(lisansbölüm.getText());
            fxmLcv.setDogum(dogum.getText());
            fxmLcv.setHobiler(hobiler.getText());
            fxmLcv.setLisestart(lisestart.getText());
            fxmLcv.setLiseend(liseend.getText());
            fxmLcv.setLisansstartt(lisansstart.getText());
            fxmLcv.setLisansend(lisansend.getText());
            fxmLcv.setÜnvan(ünvan.getText());
            fxmLcv.setIş1adı(iş1adı.getText());
            fxmLcv.setIş2adı(iş2adı.getText());
            fxmLcv.setPozisyon1(pozisyon1.getText());
            fxmLcv.setPozisyon2(pozisyon2.getText());
            fxmLcv.setAdres1(adres1.getText());
            fxmLcv.setAdres2(adres2.getText());
            fxmLcv.setIşstart1(işstart1.getText());
            fxmLcv.setIşstart2(işstart2.getText());
            fxmLcv.setIşend1I(işend1.getText());
            fxmLcv.setIşend2(işend2.getText());
            fxmLcv.setYabancı(yabancı.getText());
            fxmLcv.setImageview(ImageView.getImage());














            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);

            stage.show();



        } catch (IOException e) {
            e.printStackTrace();
        }


    }

}












