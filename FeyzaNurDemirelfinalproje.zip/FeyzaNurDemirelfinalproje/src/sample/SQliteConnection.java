package sample;

import java.sql.*;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

public class SQliteConnection {
    public static Connection Connector()  {

try{
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:src\\veritabanı.db");



        return conn;
    }catch (Exception e) {
    System.out.println(e);
    return null;
}
    }
public static Connection Connector2(){


    try{
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:src\\veritabanı.db");



        return conn;
    }catch (Exception e) {
        System.out.println(e);
        return null;
    }
}}


