package sample;

import java.sql.*;
        import javax.swing.plaf.nimbus.State;
        import javafx.application.Application;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
        import javafx.scene.Parent;
        import javafx.scene.Scene;
        import javafx.scene.layout.VBox;
        import javafx.scene.web.WebView;
        import javafx.stage.Stage;

        import javax.swing.*;
        import java.awt.*;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        String fxmlResource = "login.fxml";
        Parent panel;
        panel = FXMLLoader.load(getClass().getResource(fxmlResource));

        Scene scene = new Scene(panel);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();


    }
















    public static void main(String[] args) {

        launch(args);
    }
}
