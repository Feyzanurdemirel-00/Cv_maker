package sample;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.converter.LocalDateTimeStringConverter;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import static java.awt.Color.WHITE;

public class FXMLcv {

    @FXML
    Label isim1;
    @FXML
    Label tc;

    @FXML
    Label telefon;
    @FXML
    Label email;
    @FXML
    Label adres;
    @FXML
    Label cinsiyet;
    @FXML
    Label medenidurum;
    @FXML
    Label referans;
    @FXML
    Label referans2;
    @FXML
    Label numara1;
    @FXML
    Label numara2;
    @FXML
    Label liseadı;
    @FXML
    Label lisealan;
    @FXML
    Label lisansadı;
    @FXML
    Label lisansbölüm;
    @FXML
    ImageView imageview;

    @FXML
    Label hobiler;
    @FXML
    Label dogum;
    @FXML
    Label lisestart;
    @FXML
    Label liseend;
    @FXML
    Label lisansstartt;
    @FXML
    Label lisansend;
    @FXML
    Label ünvan;
    @FXML
    Label iş1adı;
    @FXML
    Label iş2adı;
    @FXML
    Label pozisyon1;
    @FXML
    Label adres1;
    @FXML
    Label pozisyon2;
    @FXML
    Label adres2;
    @FXML
    Label işstart1;
    @FXML
    Label işstart2;
    @FXML
    Label işend1;
    @FXML
    Label işend2;
    @FXML
    Label yabancı;




    public void initialize(URL location, ResourceBundle resources) {

    }

    public void setIsim1(String text) {

        isim1.setText(text);

    }

    public void setTc(String text) {

        tc.setText(text);

    }


    public void setTelefon(String text) {

        telefon.setText(text);

    }

    public void setEmail(String text) {

        email.setText(text);

    }

    public void setAdres(String text) {

        adres.setText(text);

    }

    public void setCinsiyet(String text) {

        cinsiyet.setText(text);

    }

    public void setMedenidurum(String text) {

        medenidurum.setText(text);

    }

    public void setReferans(String text) {

        referans.setText(text);

    }

    public void setNumara1(String text) {

        numara1.setText(text);

    }

    public void setReferans2(String text) {

        referans2.setText(text);

    }

    public void setNumara2(String text) {

        numara2.setText(text);

    }

    public void setLiseadı(String text) {

        liseadı.setText(text);

    }

    public void setLisealan(String text) {
        lisealan.setText(text);

    }

    public void setLisansadı(String text) {

        lisansadı.setText(text);

    }

    public void setLisansbölüm(String text) {

        lisansbölüm.setText(text);

    }

    public void setImageview(Image image) {
        imageview.setFitHeight(109);
        imageview.setFitWidth(108);
        Circle circle = new Circle(100);

        circle.setStrokeWidth(5);
        circle.setCenterX(imageview.getFitWidth() / 2);
        circle.setCenterY(imageview.getFitHeight() / 2);
        imageview.setClip(circle);


        imageview.setImage(image);


    }

    public void setHobiler(String text) {

        hobiler.setText(text);

    }

    public void setDogum(String text) {

        dogum.setText(text);

    }

    public void setLisestart(String text) {

        lisestart.setText(text);

    }

    public void setLiseend(String text) {

        liseend.setText(text);

    }


    public void setLisansend(String text) {

        lisansend.setText(text);

    }

    public void setLisansstartt(String text) {
        lisansstartt.setText(text);
    }

    public void setÜnvan(String text) {
        ünvan.setText(text);
    }

    public void setIş1adı(String text) {
        iş1adı.setText(text);
    }

    public void setIş2adı(String text) {
        iş2adı.setText(text);
    }

    public void setPozisyon1(String text) {
        pozisyon1.setText(text);
    }

    public void setPozisyon2(String text) {
        pozisyon2.setText(text);
    }

    public void setAdres1(String text) {
        adres1.setText(text);
    }

    public void setAdres2(String text) {
        adres2.setText(text);
    }

    public void setIşstart1(String text) {
        işstart1.setText(text);
    }

    public void setIşstart2(String text) {
        işstart2.setText(text);
    }

    public void setIşend1I(String text) {
        işend1.setText(text);
    }

    public void setIşend2(String text) {
        işend2.setText(text);
    }

    public void setYabancı(String text) {
        yabancı.setText(text);
    }



}
