package sample;
import javafx.scene.control.TextField;

import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginModel {
    Connection conection;
    Connection connection;

    public LoginModel() {
        conection = SQliteConnection.Connector();
        connection=SQliteConnection.Connector2();
        if (conection == null) {
            System.out.println("başarısız");
            System.exit(1);}
        }


    public boolean isDbConnected()  {
        try {
            return !conection.isClosed();

        }catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean Login(String user, String pass) throws SQLException {
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        String query = "select * from CVLOGIN where USERNAME = ? and PASSWORD = ?";

        try {
            preparedStatement = conection.prepareStatement(query);
            preparedStatement.setString(1,user);
            preparedStatement.setString(2,pass);
            resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }finally {
            preparedStatement.close();
            resultSet.close();
        }

    }public boolean kayitol(String name, String surname, String age, String user, String pass)throws SQLException {

        String query2 = "INSERT INTO CVLOGIN(NAME,SURNAME,AGE,USERNAME,PASSWORD) VALUES(?,?,?,?,?)";
        try {
            PreparedStatement preparedStatement1 = connection.prepareStatement(query2);


            preparedStatement1.setString(1, name);
            preparedStatement1.setString(2, surname);
            preparedStatement1.setString(3, age);
            preparedStatement1.setString(4, user);
            preparedStatement1.setString(5,pass);
            preparedStatement1.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());

        }return false;
    }


}






